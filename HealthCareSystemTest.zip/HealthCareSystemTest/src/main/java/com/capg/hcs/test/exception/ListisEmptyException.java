package com.capg.hcs.test.exception;

public class ListisEmptyException extends RuntimeException{
	
	public ListisEmptyException(String message) {
		super(message);
	}

}
