package com.capg.hcs.test.exception;

public class TestAlreadyExistException extends RuntimeException{
	
	public TestAlreadyExistException(String message) {
		super(message);
	}

}
