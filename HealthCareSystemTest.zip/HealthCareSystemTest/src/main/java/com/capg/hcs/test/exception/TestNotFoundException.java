package com.capg.hcs.test.exception;

public class TestNotFoundException extends RuntimeException{
	
	public TestNotFoundException(String message) {
		super(message);
	}

}
