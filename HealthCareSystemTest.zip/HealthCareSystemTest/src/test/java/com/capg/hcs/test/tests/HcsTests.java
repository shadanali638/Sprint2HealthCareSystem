package com.capg.hcs.test.tests;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HcsTests {

	@Test
	void contextLoads() {
	}

}
